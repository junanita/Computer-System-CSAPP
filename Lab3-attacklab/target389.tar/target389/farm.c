/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_263()
{
    return 2425393240U;
}

unsigned getval_404()
{
    return 2428995912U;
}

void setval_296(unsigned *p)
{
    *p = 3281025028U;
}

unsigned addval_136(unsigned x)
{
    return x + 3281096792U;
}

void setval_193(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_176()
{
    return 3277352597U;
}

unsigned getval_450()
{
    return 3351857252U;
}

unsigned getval_172()
{
    return 2462550344U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_150()
{
    return 3680553609U;
}

unsigned getval_392()
{
    return 2430634248U;
}

void setval_487(unsigned *p)
{
    *p = 3284240685U;
}

unsigned getval_163()
{
    return 3526412937U;
}

unsigned addval_460(unsigned x)
{
    return x + 3398257792U;
}

unsigned addval_280(unsigned x)
{
    return x + 3523794601U;
}

void setval_435(unsigned *p)
{
    *p = 3286273352U;
}

void setval_302(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_284(unsigned x)
{
    return x + 3281043881U;
}

void setval_161(unsigned *p)
{
    *p = 3229925801U;
}

unsigned getval_141()
{
    return 3229925769U;
}

void setval_216(unsigned *p)
{
    *p = 3284830570U;
}

unsigned addval_252(unsigned x)
{
    return x + 3678980745U;
}

void setval_325(unsigned *p)
{
    *p = 3680553609U;
}

void setval_120(unsigned *p)
{
    *p = 3222853257U;
}

unsigned getval_204()
{
    return 2425408137U;
}

unsigned addval_408(unsigned x)
{
    return x + 3380139657U;
}

unsigned addval_184(unsigned x)
{
    return x + 3252717896U;
}

void setval_360(unsigned *p)
{
    *p = 3676362377U;
}

unsigned getval_347()
{
    return 3286272328U;
}

void setval_162(unsigned *p)
{
    *p = 3286272328U;
}

void setval_233(unsigned *p)
{
    *p = 3674784141U;
}

void setval_312(unsigned *p)
{
    *p = 3281049289U;
}

void setval_370(unsigned *p)
{
    *p = 3229925833U;
}

unsigned getval_285()
{
    return 2464188744U;
}

void setval_185(unsigned *p)
{
    *p = 2429979114U;
}

void setval_239(unsigned *p)
{
    *p = 3247489417U;
}

unsigned addval_433(unsigned x)
{
    return x + 3286280520U;
}

void setval_437(unsigned *p)
{
    *p = 3234122377U;
}

void setval_445(unsigned *p)
{
    *p = 3225993609U;
}

unsigned getval_226()
{
    return 2425476745U;
}

unsigned addval_154(unsigned x)
{
    return x + 3676362393U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
