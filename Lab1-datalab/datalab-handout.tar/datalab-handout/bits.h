//1
int thirdBits();
int test_thirdBits();
int isTmin(int);
int test_isTmin(int);
//2
int isNotEqual(int, int);
int test_isNotEqual(int, int);
int anyOddBit();
int test_anyOddBit();
int negate(int);
int test_negate(int);
//3
int conditional(int, int, int);
int test_conditional(int, int, int);
int subOK(int, int);
int test_subOK(int, int);
int isGreater(int, int);
int test_isGreater(int, int);
//4
int bitParity(int);
int test_bitParity(int);
int howManyBits(int);
int test_howManyBits(int);
//float
unsigned float_half(unsigned);
unsigned test_float_half(unsigned);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
int float_f2i(unsigned);
int test_float_f2i(unsigned);
